# Gemini task: Xender catalog redesign
This is a scoped frontend source snapshot, not the complete backend or a deployed project.
Stack: static HTML, CSS, JavaScript. Cloudflare Worker APIs are NOT included. Do not rewrite in React or invent API implementations.

START BY READING AGENTS.md and docs/XENDER_ARCHITECTURE.md.
Inspect public/website-catalog.html, public/business-templates.html, public/sample-preview.html, public/catalog-data.js, public/portfolio.html, public/demo-frontend-store.html (North Store), public/demo-gym.html (Forge Fitness), public/demo-suite.css, public/demo-ribbon.js and scripts/commercial/.
Generated commercial pages MUST be changed through their scripts/commercial source, including portfolio via scripts/commercial/portfolio.mjs; regenerate with node scripts/build-commercial-pages.mjs. Inspect generator ownership before editing any other generated page.

TASK
Redesign the catalog and the individual demos. The problem is repeated layouts, visual sameness and weak motion. Do not just restyle the listing.
1. Inventory all catalog categories, demo routes and generator ownership actually present. State which files you inspected.
2. Implement North Store and Forge first as distinctly different complete frontend experiences, preserving existing useful functionality. North: editorial commerce, search/filter/product detail/cart quantity/removal/totals. Forge: bold athletic composition, class browsing, trainer and membership sections, validated enquiry flow. Preserve verified existing prices and business contact details. Label fictional sample content.
3. Add purposeful transitions, keyboard access, visible focus, mobile tap controls and reduced-motion support. Keep primary actions visible without hover. No identical grids across all templates, excessive glow, placeholder images or dead # links.
4. Preserve demo-ribbon labels, relevant navigation, enquiry actions and existing API contracts. No fake client claims, testimonials or conversion metrics. Demo checkout must never imply a real purchase. Form success must reflect actual behavior; if no backend is available, explicitly show a local demonstration and do not claim a sent enquiry.
5. Once the first two demos are reviewable, continue the remaining catalog items with business-specific layouts and interactions. Share a route checklist and clearly distinguish implemented from pending items.
6. Run desktop/mobile previews and functional checks. Report tests actually executed. Return the changed files, not just advice or detached snippets.

BOUNDARIES
No deployment, purchases, external messages, credential requests or production writes. Do not enable analytics/lead submissions during preview. Existing scripts such as xs-growth.js may call live-relative APIs: mock/disable network writes in the preview environment and preserve production source contracts.
Backend integration, authentication, database and payment changes require the complete repository and separate review. Missing routes/assets in this scoped snapshot are not proof that the original project lacks them.

If your current Gemini surface cannot edit imported files, say so immediately and provide exact patch files instead of pretending to implement changes. Import/upload availability depends on the AI Studio interface; do not claim a ZIP has been imported until you can inspect its files.
